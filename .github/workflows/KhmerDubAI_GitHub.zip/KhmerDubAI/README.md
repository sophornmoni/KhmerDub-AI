# KhmerDub AI

Starter Android app for AI video dubbing into Khmer.

## Current MVP
- Jetpack Compose UI
- Video dubbing home screen
- Subtitle screen placeholder
- Khmer voice screen placeholder
- No external API key required
- Designed as a clean starting point for Android Studio

## Next development steps
1. Add Android video picker
2. Extract audio
3. Speech-to-text
4. Translate to Khmer
5. Khmer text-to-speech
6. Replace/mix audio into the video
7. Export/share the dubbed video

Open the project folder `KhmerDubAI` in Android Studio and run Gradle sync.
