package com.phorn.khmerdubai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { KhmerDubApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KhmerDubApp() {
    var selected by remember { mutableStateOf(0) }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("KhmerDub AI") },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = selected == 0,
                        onClick = { selected = 0 },
                        icon = { Icon(Icons.Default.Movie, null) },
                        label = { Text("Video") }
                    )
                    NavigationBarItem(
                        selected = selected == 1,
                        onClick = { selected = 1 },
                        icon = { Icon(Icons.Default.ClosedCaption, null) },
                        label = { Text("Subtitle") }
                    )
                    NavigationBarItem(
                        selected = selected == 2,
                        onClick = { selected = 2 },
                        icon = { Icon(Icons.Default.AudioFile, null) },
                        label = { Text("Voice") }
                    )
                }
            }
        ) { padding ->
            when (selected) {
                0 -> HomeScreen(Modifier.padding(padding))
                1 -> SubtitleScreen(Modifier.padding(padding))
                else -> VoiceScreen(Modifier.padding(padding))
            }
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))
        Text("🎬", style = MaterialTheme.typography.displayLarge)
        Spacer(Modifier.height(12.dp))
        Text("AI Video Dubbing", style = MaterialTheme.typography.headlineMedium)
        Text("បម្លែងសំឡេងវីដេអូទៅជាភាសាខ្មែរ", style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(28.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(Modifier.padding(20.dp)) {
                Text("ចាប់ផ្តើម", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                Text("ជំហានបន្ទាប់ យើងនឹងភ្ជាប់ Video Picker និង AI dubbing API។")
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = { },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.PlayArrow, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Select Video")
                }
            }
        }

        Spacer(Modifier.height(20.dp))
        FeatureCard(Icons.Default.Translate, "Khmer Translation", "បកប្រែអត្ថបទទៅជាភាសាខ្មែរ")
        FeatureCard(Icons.Default.AudioFile, "Khmer Voice", "បង្កើតសំឡេង Khmer AI")
        FeatureCard(Icons.Default.ClosedCaption, "Subtitles", "បង្កើត subtitle សម្រាប់វីដេអូ")
    }
}

@Composable
fun FeatureCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, text: String) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(text, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun SubtitleScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("Subtitle", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        Text("Transcript និង Khmer subtitle នឹងបន្ថែមក្នុង version បន្ទាប់។")
    }
}

@Composable
fun VoiceScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("Khmer Voice", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        Text("Khmer AI Text-to-Speech នឹងភ្ជាប់នៅជំហានបន្ទាប់។")
    }
}
